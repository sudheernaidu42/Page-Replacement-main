import tkinter as tk
from tkinter import ttk, messagebox
from collections import deque

class PageReplacementSimulator:
    def __init__(self, root):
        self.root = root
        self.root.title("Page Replacement Algorithm Simulator")
        self.root.geometry("1000x700")
        self.setup_ui()
        
    def setup_ui(self):
        # Input Frame
        input_frame = ttk.LabelFrame(self.root, text="Input Parameters", padding=(10, 5))
        input_frame.pack(fill=tk.X, padx=10, pady=5)
        
        # Reference String
        ttk.Label(input_frame, text="Reference String (comma separated):").grid(row=0, column=0, sticky=tk.W, pady=2)
        self.ref_str_entry = ttk.Entry(input_frame, width=50)
        self.ref_str_entry.grid(row=0, column=1, sticky=tk.W, pady=2)
        self.ref_str_entry.insert(0, "1,2,3,4,1,2,5,1,2,3,4,5")
        
        # Number of Frames
        ttk.Label(input_frame, text="Number of Frames:").grid(row=1, column=0, sticky=tk.W, pady=2)
        self.frames_spinbox = ttk.Spinbox(input_frame, from_=1, to=10, width=5)
        self.frames_spinbox.grid(row=1, column=1, sticky=tk.W, pady=2)
        self.frames_spinbox.set(3)
        
        # Algorithm Selection
        ttk.Label(input_frame, text="Select Algorithms:").grid(row=2, column=0, sticky=tk.W, pady=2)
        
        self.algo_vars = {
            "FIFO": tk.BooleanVar(value=True),
            "LRU": tk.BooleanVar(value=True),
            "Optimal": tk.BooleanVar(value=True)
        }
        
        algo_frame = ttk.Frame(input_frame)
        algo_frame.grid(row=2, column=1, sticky=tk.W)
        
        for i, (algo, var) in enumerate(self.algo_vars.items()):
            cb = ttk.Checkbutton(algo_frame, text=algo, variable=var)
            cb.grid(row=0, column=i, padx=5, sticky=tk.W)
        
        # Simulate Button
        simulate_btn = ttk.Button(input_frame, text="Simulate", command=self.run_simulation)
        simulate_btn.grid(row=3, column=0, columnspan=2, pady=10)
        
        # Results Notebook
        self.results_notebook = ttk.Notebook(self.root)
        self.results_notebook.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)
        
    def run_simulation(self):
        # Clear previous results
        for tab in self.results_notebook.tabs():
            self.results_notebook.forget(tab)
        
        # Get input values
        try:
            ref_str = [int(x.strip()) for x in self.ref_str_entry.get().split(",") if x.strip()]
            frames = int(self.frames_spinbox.get())
            
            if frames < 1:
                messagebox.showerror("Error", "Number of frames must be at least 1")
                return
                
            if not ref_str:
                messagebox.showerror("Error", "Please enter a valid reference string")
                return
                
        except ValueError:
            messagebox.showerror("Error", "Invalid input values")
            return
        
        # Get selected algorithms
        selected_algos = [algo for algo, var in self.algo_vars.items() if var.get()]
        
        if not selected_algos:
            messagebox.showerror("Error", "Please select at least one algorithm")
            return
        
        # Run simulations
        for algo in selected_algos:
            if algo == "FIFO":
                result = self.fifo(ref_str, frames)
            elif algo == "LRU":
                result = self.lru(ref_str, frames)
            elif algo == "Optimal":
                result = self.optimal(ref_str, frames)
            
            self.display_result(result)
    
    def fifo(self, reference_string, frames):
        memory = []
        queue = deque()
        page_faults = 0
        steps = []

        for i, page in enumerate(reference_string):
            step = {"page": page, "frames": memory.copy(), "fault": False, "replaced": None}

            if page not in memory:
                page_faults += 1
                step["fault"] = True

                if len(memory) < frames:
                    memory.append(page)
                    queue.append(page)
                else:
                    replaced_page = queue.popleft()
                    memory[memory.index(replaced_page)] = page
                    queue.append(page)
                    step["replaced"] = replaced_page

            steps.append(step)

        return {
            "name": "FIFO",
            "page_faults": page_faults,
            "page_hits": len(reference_string) - page_faults,
            "steps": steps
        }
    
    def lru(self, reference_string, frames):
        memory = []
        recently_used = []
        page_faults = 0
        steps = []

        for i, page in enumerate(reference_string):
            step = {"page": page, "frames": memory.copy(), "fault": False, "replaced": None}

            if page not in memory:
                page_faults += 1
                step["fault"] = True

                if len(memory) < frames:
                    memory.append(page)
                else:
                    # Find least recently used page
                    lru_page = None
                    farthest = -1
                    
                    for mem_page in memory:
                        try:
                            last_used = len(recently_used) - 1 - recently_used[::-1].index(mem_page)
                        except ValueError:
                            last_used = -1
                            
                        if last_used > farthest:
                            farthest = last_used
                            lru_page = mem_page
                    
                    memory[memory.index(lru_page)] = page
                    step["replaced"] = lru_page

            recently_used.append(page)
            steps.append(step)

        return {
            "name": "LRU",
            "page_faults": page_faults,
            "page_hits": len(reference_string) - page_faults,
            "steps": steps
        }
    
    def optimal(self, reference_string, frames):
        memory = []
        page_faults = 0
        steps = []

        for i, page in enumerate(reference_string):
            step = {"page": page, "frames": memory.copy(), "fault": False, "replaced": None}

            if page not in memory:
                page_faults += 1
                step["fault"] = True

                if len(memory) < frames:
                    memory.append(page)
                else:
                    # Find page that won't be used for longest time
                    farthest = -1
                    replace_index = 0
                    
                    for j, mem_page in enumerate(memory):
                        try:
                            next_use = reference_string[i+1:].index(mem_page)
                        except ValueError:
                            next_use = -1
                        
                        if next_use == -1:
                            replace_index = j
                            break
                        elif next_use > farthest:
                            farthest = next_use
                            replace_index = j
                    
                    step["replaced"] = memory[replace_index]
                    memory[replace_index] = page

            steps.append(step)

        return {
            "name": "Optimal",
            "page_faults": page_faults,
            "page_hits": len(reference_string) - page_faults,
            "steps": steps
        }
    
    def display_result(self, result):
        # Create a tab for this algorithm
        tab = ttk.Frame(self.results_notebook)
        self.results_notebook.add(tab, text=result["name"])
        
        # Metrics frame
        metrics_frame = ttk.LabelFrame(tab, text="Metrics", padding=(10, 5))
        metrics_frame.pack(fill=tk.X, padx=5, pady=5)
        
        # Display metrics
        ttk.Label(metrics_frame, text=f"Page Faults: {result['page_faults']}").pack(side=tk.LEFT, padx=10)
        ttk.Label(metrics_frame, text=f"Page Hits: {result['page_hits']}").pack(side=tk.LEFT, padx=10)
        hit_ratio = result['page_hits'] / len(result['steps']) * 100
        ttk.Label(metrics_frame, text=f"Hit Ratio: {hit_ratio:.2f}%").pack(side=tk.LEFT, padx=10)
        
        # Steps frame
        steps_frame = ttk.LabelFrame(tab, text="Step-by-Step Execution", padding=(10, 5))
        steps_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # Create treeview for steps
        columns = ["Step", "Page"] + [f"Frame {i+1}" for i in range(len(result['steps'][0]['frames']))] + ["Status", "Replaced"]
        tree = ttk.Treeview(steps_frame, columns=columns, show="headings", height=min(20, len(result['steps'])))
        
        # Configure columns
        for col in columns:
            tree.heading(col, text=col)
            tree.column(col, width=80, anchor=tk.CENTER)
        
        # Add data
        for i, step in enumerate(result['steps'], 1):
            values = [i, step['page']]
            values.extend(step['frames'])
            # Fill empty frames if needed
            values.extend(['-'] * (len(result['steps'][0]['frames']) - len(step['frames'])))
            values.append("Fault" if step['fault'] else "Hit")
            values.append(step['replaced'] if step['replaced'] else '-')
            tree.insert("", tk.END, values=values)
        
        # Add scrollbar
        scrollbar = ttk.Scrollbar(steps_frame, orient=tk.VERTICAL, command=tree.yview)
        tree.configure(yscroll=scrollbar.set)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        tree.pack(fill=tk.BOTH, expand=True)
        
        # Color rows
        for i, step in enumerate(result['steps']):
            if step['fault']:
                tree.tag_configure(f'fault{i}', background='#ffdddd')
                tree.item(tree.get_children()[i], tags=(f'fault{i}',))
            else:
                tree.tag_configure(f'hit{i}', background='#ddffdd')
                tree.item(tree.get_children()[i], tags=(f'hit{i}',))

if __name__ == "__main__":
    root = tk.Tk()
    app = PageReplacementSimulator(root)
    root.mainloop()